// ==UserScript==
// @name         Bing → Google button in search form
// @namespace    http://tampermonkey.net/
// @version      2.0
// @description  Inserts a button inside Bing's search form (#sb_form) to open the query on Google
// @author       theoffbeatdoc
// @match        https://www.bing.com/*
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  const BUTTON_ID = 'bing-to-google-btn';

  function getSearchInput() {
    return document.querySelector('#sb_form_q, input[name="q"]');
  }

  function getQuery() {
    const input = getSearchInput();
    return (input && input.value) ? input.value.trim() : '';
  }

  function createButton() {
    if (document.getElementById(BUTTON_ID)) return null;

    const btn = document.createElement('button');
    btn.id = BUTTON_ID;
    btn.type = 'button';
    btn.textContent = 'Google Search';
    btn.style.marginLeft = '6px';
    btn.style.padding = '10px 10px';
    btn.style.fontSize = '15px';
    btn.style.border = '1px solid #ccc';
    btn.style.borderRadius = '25px';
    btn.style.background = '#fff';
    btn.style.cursor = 'pointer';

    btn.addEventListener('click', () => {
      const q = getQuery();
      if (!q) return;
      const url = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
      window.open(url, '_blank', 'noopener');
    });

    return btn;
  }

  function insertButton() {
    const form = document.querySelector('#sb_form');
    if (!form) return false;

    if (document.getElementById(BUTTON_ID)) return true;

    const btn = createButton();
    if (btn) form.appendChild(btn);
    return true;
  }

  function init() {
    insertButton();

    // Observe for dynamic changes (Bing often re-renders the form)
    const observer = new MutationObserver(() => {
      insertButton();
    });
    observer.observe(document.body, { childList: true, subtree: true });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
