// ==UserScript==
// @name         DailyEpaper Cleaner
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Hides clutter, adds a logo, and centers main content on www.dailyepaper.in like uBlock filters do, plus more!
// @author       theoffbeatdoc
// @match        *://www.dailyepaper.in/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    const hideSelectors = [
        '.wptb-table-container-matrix',
        '.mh-clearfix.entry-content > p.p1',
        '.mh-site-logo',
        '.mh-clearfix.mh-container-inner.mh-container.mh-main-nav.mh-navigation',
        '.wp-block-search.wp-block-search__text-button.wp-block-search__button-outside',
        '.entry-title',
        '.mh-footer',
        '.crp-masonry.crp_related',
        'h2.p3',
        '.mh-clearfix.entry-header',
        '.ol1',
        '.mh-sidebar.mh-widget-col-1',
        'p:nth-of-type(2)',
        'h3.p1 > span > b',
        'td:nth-of-type(1)',
        'table:nth-of-type(1)',
        'table.t1:nth-of-type(2)',
        'p.p2:nth-of-type(10)',
        'p.p2:nth-of-type(11)',
        'h3.p3 > span > b',
        'td.td1:nth-of-type(2)',
        'td:nth-of-type(2)',
        'table:nth-of-type(4)',
        '.p5 > span > b',
        'p:nth-of-type(13)',
        '.mh-clearfix.entry-content > p.p3',
        '.mh-clearfix.mh-row.mh-post-nav',
        '.mh-copyright-wrap'
    ];

    const hideImagesBySrc = [
        'https://dailyepaper.in/wp-content/uploads/2023/08/11-2-300x167.webp'
    ];

    function hideElements() {
        hideSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => {
                el.style.display = 'none';
            });
        });

        hideImagesBySrc.forEach(src => {
            document.querySelectorAll(`img[src="${src}"]`).forEach(img => {
                img.style.display = 'none';
            });
        });
    }

    function addLogo() {
        const logo = document.createElement('img');
        logo.src = 'https://img.etimg.com/photo/96706126.cms';
        logo.alt = 'Custom Logo';
        logo.style.cssText = `
            display: block;
            max-width: 200px;
            margin: 20px auto;
            padding: 10px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.2);
        `;

        const wrapper = document.createElement('div');
        wrapper.style.textAlign = 'center';
        wrapper.appendChild(logo);

        document.body.insertBefore(wrapper, document.body.firstChild);
    }

    function centerMainContent() {
        const main = document.querySelector('#main-content');
        if (main) {
            main.style.margin = '0 auto';
            main.style.maxWidth = '800px';
            main.style.padding = '20px';
            main.style.backgroundColor = 'white'; // Optional: make it pop
            main.style.boxShadow = '0 2px 10px rgba(0,0,0,0.05)';
            main.style.borderRadius = '8px';
        }
    }

    // Run everything once DOM is loaded
    window.addEventListener('load', () => {
        addLogo();
        hideElements();
        centerMainContent();
    });

    // In case content loads dynamically (AJAX, etc.)
    const observer = new MutationObserver(() => {
        hideElements();
        centerMainContent();
    });
    observer.observe(document.body, { childList: true, subtree: true });
})();
