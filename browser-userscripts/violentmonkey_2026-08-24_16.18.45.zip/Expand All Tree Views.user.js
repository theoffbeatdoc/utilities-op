// ==UserScript==
// @name         Expand All Tree Views
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Automatically expand all tree view elements on a webpage
// @author       Your Name
// @match        https://go.drugbank.com/atc
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Adjust the selector to match the tree view toggle buttons or elements
    const treeToggles = document.querySelectorAll('.jstree-icon .jstree-ocl');

    treeToggles.forEach(toggle => {
        if (toggle.getAttribute('aria-expanded') === 'false' || toggle.classList.contains('collapsed')) {
            toggle.click(); // Simulate a click to expand
        }
    });

    console.log(`${treeToggles.length} tree views expanded.`);
})();
