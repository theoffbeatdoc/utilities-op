// ==UserScript==
// @name         LinkedIn Name Auto-Replace in Messages 2
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Replace {{name}} placeholder with recipient's name when pasting in LinkedIn messages (works on main messaging and popup modals)
// @author       You
// @match        https://www.linkedin.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to extract the person's name from the main messaging page
    function getRecipientNameMainPage() {
        const selectors = [
            'h2.msg-entity-lockup__entity-title',
            '.msg-entity-lockup__entity-title',
            '.msg-thread-banner__recipient-name',
            '.msg-conversation-listitem__participant-names',
            'h1[data-test-id="conversation-details-name"]'
        ];

        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                const name = element.textContent.trim();
                if (name && name.length > 0) {
                    console.log('Found name on main page:', name);
                    return name;
                }
            }
        }

        // Fallback for main page
        const h2Elements = document.querySelectorAll('h2');
        for (const h2 of h2Elements) {
            if (h2.className && h2.className.includes('msg-entity-lockup__entity-title')) {
                const name = h2.textContent.trim();
                if (name) {
                    console.log('Found name via fallback (main page):', name);
                    return name;
                }
            }
        }

        return null;
    }

    // Function to extract the person's name from the popup modal (profile → Message)
    function getRecipientNamePopupModal() {
        // Selectors for the popup modal name
        const popupSelectors = [
            '.artdeco-entity-lockup__title .profile-card-one-to-one__profile-link span',
            '.artdeco-entity-lockup__title span.truncate',
            '.msg-overlay-bubble-header__title',
            '.artdeco-modal__header h1',
            '.msg-overlay-conversation-bubble__header h2',
            // Additional selectors for different modal variations
            '.artdeco-entity-lockup__title a[data-test-app-aware-link] span',
            '.msg-overlay .msg-entity-lockup__title',
            '.msg-overlay-bubble-header__entity-link'
        ];

        for (const selector of popupSelectors) {
            const elements = document.querySelectorAll(selector);
            for (const element of elements) {
                const name = element.textContent.trim();
                if (name && name.length > 0 && !name.includes('·')) {
                    console.log('Found name in popup modal:', name, 'via selector:', selector);
                    return name;
                }
            }
        }

        // Try to find modal by its structure
        const modalTitles = document.querySelectorAll('.artdeco-entity-lockup__title');
        for (const title of modalTitles) {
            // Look for the name span within the modal title
            const nameSpan = title.querySelector('span.truncate:first-child');
            if (nameSpan) {
                const name = nameSpan.textContent.trim();
                if (name) {
                    console.log('Found name in modal title structure:', name);
                    return name;
                }
            }

            // Alternative: get text content and clean it
            const text = title.textContent.trim();
            if (text && !text.includes('·') && text.length < 100) {
                // Clean up - remove degree connection text if present
                const cleaned = text.replace(/·\s*\d+(st|nd|rd|th)/g, '').trim();
                if (cleaned) {
                    console.log('Found name by cleaning modal text:', cleaned);
                    return cleaned;
                }
            }
        }

        // Check if we're in a message overlay bubble
        const bubbleHeader = document.querySelector('.msg-overlay-bubble-header__title');
        if (bubbleHeader) {
            const name = bubbleHeader.textContent.trim();
            if (name) {
                console.log('Found name in bubble header:', name);
                return name;
            }
        }

        return null;
    }

    // Main function to get recipient name (tries both locations)
    function getRecipientName() {
        // First try popup modal (profile message popup)
        let name = getRecipientNamePopupModal();

        // If not found in popup, try main messaging page
        if (!name) {
            name = getRecipientNameMainPage();
        }

        if (!name) {
            console.warn('Could not find recipient name on page');

            // Debug: Log all potential name elements
            if (window.location.href.includes('linkedin.com/messaging')) {
                console.log('Debug - All h2 elements:');
                document.querySelectorAll('h2').forEach((el, i) => {
                    console.log(`h2[${i}]:`, el.className, 'text:', el.textContent.trim());
                });
            }

            // Debug for modal
            const modalElements = document.querySelectorAll('.artdeco-entity-lockup__title, .msg-overlay-bubble-header__title');
            console.log('Debug - Modal elements:', modalElements.length);
            modalElements.forEach((el, i) => {
                console.log(`Modal[${i}]:`, el.className, 'text:', el.textContent.trim());
            });
        } else {
            console.log('Using recipient name:', name);
        }

        return name;
    }

    // Function to handle paste events
    function handlePaste(event) {
        // Get recipient name
        const recipientName = getRecipientName();
        if (!recipientName) return;

        // Get pasted data
        const clipboardData = event.clipboardData || window.clipboardData;
        const pastedText = clipboardData.getData('text');

        // Check if pasted text contains {{name}}
        if (pastedText && pastedText.includes('{{name}}')) {
            // Prevent default paste
            event.preventDefault();

            // Replace {{name}} with actual name
            const replacedText = pastedText.replace(/\{\{name\}\}/g, recipientName);

            // Insert the modified text
            const target = event.target;
            if (target.isContentEditable || target.tagName === 'TEXTAREA' || target.tagName === 'INPUT') {
                // For contenteditable elements (LinkedIn uses these)
                if (target.isContentEditable) {
                    document.execCommand('insertText', false, replacedText);
                } else {
                    // For textarea/input
                    const start = target.selectionStart;
                    const end = target.selectionEnd;
                    const before = target.value.substring(0, start);
                    const after = target.value.substring(end);
                    target.value = before + replacedText + after;

                    // Move cursor to end of inserted text
                    const newCursorPos = start + replacedText.length;
                    target.setSelectionRange(newCursorPos, newCursorPos);
                }

                console.log('Replaced {{name}} with:', recipientName);

                // Trigger input event for LinkedIn's UI to update
                target.dispatchEvent(new Event('input', { bubbles: true }));
            }
        }
    }

    // Function to find message input fields in both locations
    function findMessageInputs() {
        const selectors = [
            // Main messaging page
            '.msg-form__contenteditable',
            '.msg-form__message-texteditor',
            'div[data-test-msg-form][contenteditable="true"]',

            // Popup modal selectors
            '.msg-overlay .msg-form__contenteditable',
            '.msg-overlay-bubble .msg-form__message-texteditor',
            '.artdeco-modal .msg-form__contenteditable',

            // Generic selectors
            'div[contenteditable="true"][role="textbox"]',
            'div[contenteditable="true"][aria-label*="message"]',
            'div[contenteditable="true"][aria-label*="Message"]',
            'div[contenteditable="true"][data-artdeco-is-focused="true"]',

            // Fallback - any contenteditable in message forms
            '.msg-form div[contenteditable="true"]',
            '.message-anywhere-form div[contenteditable="true"]'
        ];

        const inputs = [];

        for (const selector of selectors) {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                // Filter to only message input fields (not other editable areas)
                if (isMessageInputField(element)) {
                    inputs.push(element);
                }
            });
        }

        return inputs;
    }

    // Check if element is likely a message input field
    function isMessageInputField(element) {
        if (!element.hasAttribute('contenteditable')) return false;

        // Check parent hierarchy for message form indicators
        let parent = element;
        for (let i = 0; i < 5; i++) {
            if (!parent) break;

            const className = parent.className || '';
            if (typeof className === 'string' && (
                className.includes('msg-form') ||
                className.includes('message-form') ||
                className.includes('messaging') ||
                parent.getAttribute('data-test-id')?.includes('message') ||
                parent.getAttribute('aria-label')?.toLowerCase().includes('message')
            )) {
                return true;
            }
            parent = parent.parentElement;
        }

        // Check aria attributes
        const ariaLabel = element.getAttribute('aria-label') || '';
        if (ariaLabel.toLowerCase().includes('message') ||
            ariaLabel.toLowerCase().includes('write')) {
            return true;
        }

        return false;
    }

    // Function to attach listeners to message input fields
    function attachPasteListeners() {
        const inputs = findMessageInputs();

        inputs.forEach(input => {
            // Only attach listener if not already attached
            if (!input.hasAttribute('data-name-replace-listener')) {
                input.addEventListener('paste', handlePaste, true);
                input.setAttribute('data-name-replace-listener', 'true');
                console.log('Attached paste listener to message input');
            }
        });

        // Also listen for new message modal openings
        attachModalOpenListener();
    }

    // Listen for when new message modals open
    function attachModalOpenListener() {
        // Check if a message modal is currently open
        const modals = document.querySelectorAll('.msg-overlay, .artdeco-modal[role="dialog"]');
        modals.forEach(modal => {
            if (!modal.hasAttribute('data-message-modal-watched')) {
                // Watch for input fields appearing in this modal
                const modalObserver = new MutationObserver(() => {
                    attachPasteListeners();
                });

                modalObserver.observe(modal, {
                    childList: true,
                    subtree: true
                });

                modal.setAttribute('data-message-modal-watched', 'true');
            }
        });
    }

    // Initialize the script
    function init() {
        console.log('LinkedIn Name Auto-Replace script loaded v1.1');

        // Initial attachment
        attachPasteListeners();

        // Set up mutation observer for dynamically loaded content
        const observer = new MutationObserver((mutations) => {
            let shouldCheck = false;

            mutations.forEach((mutation) => {
                if (mutation.addedNodes.length > 0) {
                    shouldCheck = true;
                }
            });

            if (shouldCheck) {
                // Debounce to avoid excessive calls
                clearTimeout(observer.timeout);
                observer.timeout = setTimeout(attachPasteListeners, 300);
            }
        });

        // Start observing the document body for changes
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // Also check periodically (useful for modals that might be missed)
        setInterval(attachPasteListeners, 1500);

        // Listen for URL changes (LinkedIn uses SPA navigation)
        let lastUrl = location.href;
        new MutationObserver(() => {
            const url = location.href;
            if (url !== lastUrl) {
                lastUrl = url;
                // Small delay to let page render
                setTimeout(attachPasteListeners, 500);
            }
        }).observe(document, { subtree: true, childList: true });
    }

    // Wait for page to load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        // Small delay to ensure LinkedIn's JS has loaded
        setTimeout(init, 1000);
    }
})();