// ==UserScript==
// @name         LinkedIn Name Auto-Replace in Messages
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  Replace {{name}} placeholder with recipient's name when pasting in LinkedIn messages
// @author       theoffbeatdoc
// @match        https://www.linkedin.com/messaging*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Function to extract the person's name from the page
    function getRecipientName() {
        // Try multiple selectors as LinkedIn might change their HTML structure
        const selectors = [
            'h2.msg-entity-lockup__entity-title',
            '.msg-entity-lockup__entity-title',
            '.msg-thread-banner__recipient-name',
            '.msg-conversation-listitem__participant-names',
            'h1[data-test-id="conversation-details-name"]'
        ];

        for (const selector of selectors) {
            const element = document.querySelector(selector);
            if (element) {
                const name = element.textContent.trim();
                if (name && name.length > 0) {
                    console.log('Found name:', name);
                    return name;
                }
            }
        }

        // Fallback: Look for any h2 with the specific class pattern
        const h2Elements = document.querySelectorAll('h2');
        for (const h2 of h2Elements) {
            if (h2.className && h2.className.includes('msg-entity-lockup__entity-title')) {
                const name = h2.textContent.trim();
                if (name) {
                    console.log('Found name via fallback:', name);
                    return name;
                }
            }
        }

        console.warn('Could not find recipient name on page');
        return null;
    }

    // Function to handle paste events
    function handlePaste(event) {
        // Only process if we have a name
        const recipientName = getRecipientName();
        if (!recipientName) return;

        // Get pasted data
        const clipboardData = event.clipboardData || window.clipboardData;
        const pastedText = clipboardData.getData('text');

        // Check if pasted text contains {{name}}
        if (pastedText && pastedText.includes('{{name}}')) {
            // Prevent default paste
            event.preventDefault();

            // Replace {{name}} with actual name
            const replacedText = pastedText.replace(/\{\{name\}\}/g, recipientName);

            // Insert the modified text
            const target = event.target;
            if (target.isContentEditable || target.tagName === 'TEXTAREA' || target.tagName === 'INPUT') {
                // For contenteditable elements
                if (target.isContentEditable) {
                    document.execCommand('insertText', false, replacedText);
                } else {
                    // For textarea/input
                    const start = target.selectionStart;
                    const end = target.selectionEnd;
                    const before = target.value.substring(0, start);
                    const after = target.value.substring(end);
                    target.value = before + replacedText + after;

                    // Move cursor to end of inserted text
                    const newCursorPos = start + replacedText.length;
                    target.setSelectionRange(newCursorPos, newCursorPos);
                }
            }

            console.log('Replaced {{name}} with:', recipientName);
        }
    }

    // Function to find and attach listeners to message input fields
    function attachPasteListeners() {
        // LinkedIn's message input fields
        const selectors = [
            'div[contenteditable="true"]',
            '.msg-form__contenteditable',
            '.msg-form__message-texteditor',
            'textarea[data-test-id="compose-message"]',
            'div[role="textbox"]'
        ];

        for (const selector of selectors) {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                // Only attach listener if not already attached
                if (!element.hasAttribute('data-name-replace-listener')) {
                    element.addEventListener('paste', handlePaste, true);
                    element.setAttribute('data-name-replace-listener', 'true');
                    console.log('Attached paste listener to element:', selector);
                }
            });
        }
    }

    // Initialize and set up mutation observer to handle dynamic content
    function init() {
        console.log('LinkedIn Name Auto-Replace script loaded');

        // Initial attachment
        attachPasteListeners();

        // Set up mutation observer for dynamically loaded content
        const observer = new MutationObserver((mutations) => {
            let shouldAttach = false;

            mutations.forEach((mutation) => {
                if (mutation.addedNodes.length > 0) {
                    shouldAttach = true;
                }
            });

            if (shouldAttach) {
                // Debounce to avoid excessive calls
                clearTimeout(observer.timeout);
                observer.timeout = setTimeout(attachPasteListeners, 300);
            }
        });

        // Start observing the document body for changes
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

        // Also re-attach periodically in case mutation observer misses something
        setInterval(attachPasteListeners, 2000);
    }

    // Wait for page to load
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();