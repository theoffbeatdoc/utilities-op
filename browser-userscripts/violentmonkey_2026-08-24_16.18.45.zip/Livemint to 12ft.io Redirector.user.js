// ==UserScript==

// @name         Livemint to 12ft.io Redirector

// @namespace    http://tampermonkey.net/

// @version      1.0

// @description  Redirects Livemint articles to 12ft.io to bypass paywall

// @author       Your Name

// @match        *://*.livemint.com/*

// @exclude      *://12ft.io/*

// @grant        none

// @run-at       document-start

// ==/UserScript==

(function() {

    'use strict';

    // Check if the current URL is a Livemint article (not the homepage)

    if (window.location.hostname.includes('livemint.com') &&

        !window.location.pathname.match(/^\/?$/)) {



        // Check if we're already in a 12ft.io URL to prevent infinite redirects

        if (!window.location.href.includes('12ft.io')) {

            // Redirect to 12ft.io version

            window.location.href = 'https://12ft.io/' + window.location.href;

        }

    }

})();





