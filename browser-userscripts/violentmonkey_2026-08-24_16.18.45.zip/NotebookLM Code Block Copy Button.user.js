// ==UserScript==
// @name         NotebookLM Code Block Copy Button
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Adds a 'Copy to Clipboard' button to code blocks in NotebookLM
// @author       theoffbeatdoc
// @match        https://notebooklm.google.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=notebooklm.google.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 1. Define the styles for the button
    const styles = `
        /* Make the <pre> tag a container for the button */
        pre {
            position: relative;
        }

        /* Style the copy button */
        .nbklm-copy-button {
            position: absolute;
            top: 8px;
            right: 8px;
            z-index: 10;
            padding: 4px 8px;
            background-color: #f0f0f0;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            color: #333;
            opacity: 0; /* Hide by default */
            transition: opacity 0.2s ease-in-out, background-color 0.2s ease;
        }

        /* Show the button when hovering over the code block */
        pre:hover .nbklm-copy-button {
            opacity: 1;
        }

        /* Button hover/active states */
        .nbklm-copy-button:hover {
            background-color: #e0e0e0;
        }
        .nbklm-copy-button:active {
            background-color: #d0d0d0;
        }

        /* State after copying */
        .nbklm-copy-button.copied {
            background-color: #d4edda; /* Light green */
            color: #155724;
            border-color: #c3e6cb;
        }
    `;

    // 2. Inject the styles into the document's <head>
    const styleSheet = document.createElement("style");
    styleSheet.innerText = styles;
    document.head.appendChild(styleSheet);

    // 3. Function to add a copy button to a <pre> element
    function addCopyButton(preElement) {
        // Prevent adding multiple buttons
        if (preElement.querySelector('.nbklm-copy-button')) {
            return;
        }

        const button = document.createElement('button');
        button.innerText = 'Copy';
        button.className = 'nbklm-copy-button';

        // 4. Add the click event listener
        button.addEventListener('click', async () => {
            // Find the <code> element, or fall back to the <pre> inner text
            const code = preElement.querySelector('code')?.innerText || preElement.innerText;

            try {
                // Use the modern, secure Clipboard API
                await navigator.clipboard.writeText(code);

                // Visual feedback
                button.innerText = 'Copied!';
                button.classList.add('copied');

                // Reset button after 2 seconds
                setTimeout(() => {
                    button.innerText = 'Copy';
                    button.classList.remove('copied');
                }, 2000);
            } catch (err) {
                console.error('Failed to copy text: ', err);
                button.innerText = 'Error';
                setTimeout(() => {
                    button.innerText = 'Copy';
                }, 2000);
            }
        });

        preElement.appendChild(button);
    }

    // 5. Use a MutationObserver to watch for new elements
    // This is necessary because NotebookLM loads content dynamically (it's a SPA)
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            mutation.addedNodes.forEach((node) => {
                // Check if the added node is an element
                if (node.nodeType === 1) {
                    // Check if the added node itself is a <pre> tag
                    if (node.matches('pre')) {
                        addCopyButton(node);
                    }
                    // Check if the added node *contains* <pre> tags
                    node.querySelectorAll('pre').forEach(addCopyButton);
                }
            });
        });
    });

    // 6. Start observing the entire document body for changes
    observer.observe(document.body, {
        childList: true, // Watch for added/removed children
        subtree: true    // Watch all descendants
    });

    // 7. Run once on load for any <pre> elements that are already present
    document.querySelectorAll('pre').forEach(addCopyButton);

})();