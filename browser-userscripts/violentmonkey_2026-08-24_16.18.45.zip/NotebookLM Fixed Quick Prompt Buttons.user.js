// ==UserScript==
// @name         NotebookLM Fixed Quick Prompt Buttons
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Adds a fixed panel of buttons at the top of the screen to paste predefined prompts into NotebookLM.
// @author       theoffbeatdoc
// @match        https://notebooklm.google.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=notebooklm.google.com
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // --- 1. DEFINE YOUR PROMPTS HERE ---

    // Prompt 1: Article Generation
    const PROMPT_1 = `**TASK:** Synthesize a **fresh, original, and comprehensive article** based **ONLY** on the selected sources.

**CORE REQUIREMENTS:**
1.  **Clarity and Conciseness:** The article must be direct and to the point. **Do not beat around the bush** or include overly verbose sentences. Prioritize **clarity and efficiency** of information delivery.
2.  **Completeness:** **Do not skip any significant information** presented across the sources. All core facts, arguments, and details must be included and integrated logically.
3.  **Originality (No Plagiarism):** The final output must be an **entirely new synthesis** of the information, written in a unique voice and structure. **Do not use any direct quotes or copy sentence structure** from the sources.
4.  **No Citations:** **DO NOT include any in-text citations, footnotes, source links, or references** in the body of the article. The final text must be clean and immediately copy-pasteable.
5.  **Structure and Organization:** The article must follow a **logical and well-organized structure** with clear headings and subheadings. Include at least **one section that uses bullet points** for enhanced readability.

**OUTPUT INSTRUCTIONS:**
Generate the entire response using **three separate Markdown code blocks** in this exact order:

**First Code Block (Title):**
* Generate a **compelling and informative article title** based on the sources.

**Second Code Block (SEO Description):**
* Generate an **SEO-friendly one-to-two-line summary** of the article.

**Third Code Block (Article Body):**
* Generate the complete, synthesized, and highly structured article.
`;

    // Prompt 2: Summary (Edit this!)
    const PROMPT_2 = `Summarize the key points from all sources in a concise bulleted list.`;

    // Prompt 3: Compare/Contrast (Edit this!)
    const PROMPT_3 = `**TASK:** Convert the provided article into a compelling, visually structured Instagram carousel post. The post must contain a minimum of 6 slides and a maximum of 10 slides, with the total number of slides determined by the best way to break down the information uniformly.

**FORMATTING RULES:**
1.  The entire output must be contained within a single Markdown code block.
2.  Separate each slide using a horizontal rule (---) on its own line.

**CONTENT RULES:**
1.  **SLIDE 1 (The Hook):**
    * Generate a highly **exciting and click-worthy title** suitable for a social media hook.
    * Include a single, very brief line of introductory text (max 10 words).
    * This slide must maximize whitespace and serve as the main image prompt.
2.  **SLIDES 2 to FINAL SLIDE (The Breakdown):**
    * Distill all core information, structure, and key details from the article across these subsequent slides.
    * The amount of text/content on these slides must be as **uniform** as possible (aim for **3-5 clear sentences or 3-5 bullet points** per slide) to ensure easy reading.
    * Use an engaging, direct, and high-energy tone suitable for social media.
    * The **final slide** should include a clear **Call to Action (CTA)**, such as "Save this post!" or "Follow for more insights!"
`;

    // --- 2. STYLES FOR THE FIXED PANEL AND BUTTONS ---
    const styles = `
        #gm-fixed-prompt-container {
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            z-index: 9999;
            background: #ffffff;
            border: 1px solid #dadce0;
            border-radius: 8px;
            padding: 8px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            display: flex;
            gap: 8px;
        }
        .gm-prompt-button {
            padding: 6px 12px;
            font-size: 13px;
            font-weight: 500;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background-color: #f1f3f4;
            border: 1px solid #dadce0;
            border-radius: 6px;
            cursor: pointer;
            color: #3c4043;
            transition: background-color 0.2s ease, box-shadow 0.2s ease;
        }
        .gm-prompt-button:hover {
            background-color: #f8f9fa;
            border-color: #c6c6c6;
            box-shadow: 0 1px 1px rgba(0,0,0,0.05);
        }
        .gm-prompt-button:active {
            background-color: #e8eaed;
        }
    `;

    // Inject styles into the page
    const styleSheet = document.createElement("style");
    styleSheet.innerText = styles;
    document.head.appendChild(styleSheet);

    // --- 3. HELPER FUNCTION TO PASTE TEXT ---
    function pastePrompt(promptText) {
        // --- THIS IS THE CORRECTED LINE ---
        // We now target the textarea using the aria-label you provided.
        const textarea = document.querySelector('textarea[aria-label="Query box"]');

        if (textarea) {
            textarea.value = promptText;
            // Dispatch an 'input' event to make the app (React) recognize the change
            textarea.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
            textarea.focus();
        } else {
            console.error('Quick Prompt Script: Could not find textarea[aria-label="Query box"].');
            alert('Could not find the NotebookLM prompt box!');
        }
    }

    // --- 4. FUNCTION TO CREATE AND INJECT BUTTONS ---
    function injectButtonContainer() {
        // Stop if buttons are already injected
        if (document.getElementById('gm-fixed-prompt-container')) {
            return;
        }

        // Create a container for our buttons
        const container = document.createElement('div');
        container.id = 'gm-fixed-prompt-container';

        // --- Create Button 1 (Article) ---
        const button1 = document.createElement('button');
        button1.innerText = 'Compose'; // Button label
        button1.title = 'Paste Article Generation Prompt'; // Tooltip
        button1.className = 'gm-prompt-button';
        button1.addEventListener('click', () => pastePrompt(PROMPT_1));

        // --- Create Button 2 ---
        const button2 = document.createElement('button');
        button2.innerText = 'Tweet'; // Button label
        button2.title = 'Paste Prompt 2'; // Tooltip
        button2.className = 'gm-prompt-button';
        button2.addEventListener('click', () => pastePrompt(PROMPT_2));

        // --- Create Button 3 ---
        const button3 = document.createElement('button');
        button3.innerText = 'Carousel'; // Button label
        button3.title = 'Paste Prompt 3'; // Tooltip
        button3.className = 'gm-prompt-button';
        button3.addEventListener('click', () => pastePrompt(PROMPT_3));

        // Add buttons to the container
        container.appendChild(button1);
        container.appendChild(button2);
        container.appendChild(button3);

        // Add the container directly to the document body
        document.body.appendChild(container);
    }

    // --- 5. RUN THE SCRIPT ---
    // We can just run this once. The container is fixed,
    // and the paste function will find the textarea when it's needed.
    injectButtonContainer();

})();