// ==UserScript==
// @name         Scribd Download Buttons
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Adds buttons to open Scribd pages in vPDFs or vDownloaders domains
// @author       theoffbeatdoc
// @match        https://www.scribd.com/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Helper to create styled buttons
    function createButton(label, bgColor, onClick) {
        const btn = document.createElement("button");
        btn.innerText = label;
        btn.style.position = "fixed";
        btn.style.top = "10px";
        btn.style.right = btns.length * 120 + 10 + "px"; // offset each button
        btn.style.zIndex = "9999";
        btn.style.padding = "8px 12px";
        btn.style.backgroundColor = bgColor;
        btn.style.color = "white";
        btn.style.border = "none";
        btn.style.borderRadius = "4px";
        btn.style.cursor = "pointer";
        btn.style.fontSize = "14px";
        btn.addEventListener("click", onClick);
        document.body.appendChild(btn);
        btns.push(btn);
    }

    const btns = [];

    // Button 1: vPDFs
    createButton("Free DL", "#4CAF50", () => {
        const currentUrl = window.location.href;
        const newUrl = currentUrl.replace("https://www.scribd.com", "https://scribd.vpdfs.com");
        window.open(newUrl, "_blank");
    });

    // Button 2: vDownloaders
    createButton("Free DL 2", "#2196F3", () => {
        const currentUrl = window.location.href;
        const newUrl = currentUrl.replace("https://www.scribd.com", "https://www.scribd.vdownloaders.com");
        window.open(newUrl, "_blank");
    });
})();
