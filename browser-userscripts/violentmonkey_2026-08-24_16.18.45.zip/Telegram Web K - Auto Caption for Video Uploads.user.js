// ==UserScript==
// @name         Telegram Web K - Auto Caption for Video Uploads
// @namespace    http://tampermonkey.net/
// @version      1.5
// @description  Automatically insert the filename as caption when uploading video files on Telegram Web K. Targets only popup caption input, not main message bar. Includes console logs for debugging.
// @author       theoffbeatdoc
// @match        https://web.telegram.org/k/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let lastVideoFilename = null;

    console.log('[TG Caption Script] ✅ Script loaded.');

    // Detect drag & drop
    document.addEventListener('drop', (e) => {
        console.log('[TG Caption Script] 🔽 Drop event detected');

        const videoFile = [...e.dataTransfer.files].find(file =>
            file.type.startsWith('video/') || file.name.match(/\.(mp4|mkv|webm|avi)$/i)
        );

        if (videoFile) {
            lastVideoFilename = videoFile.name.replace(/\.[^/.]+$/, '');
            console.log(`[TG Caption Script] 📁 Video dropped: "${videoFile.name}"`);
        } else {
            console.log('[TG Caption Script] ❌ No video file found in drop.');
        }
    }, true);

    // Detect manual file picker
    document.addEventListener('change', (e) => {
        const input = e.target;
        if (input && input.type === 'file') {
            const videoFile = [...input.files].find(file =>
                file.type.startsWith('video/') || file.name.match(/\.(mp4|mkv|webm|avi)$/i)
            );

            if (videoFile) {
                lastVideoFilename = videoFile.name.replace(/\.[^/.]+$/, '');
                console.log(`[TG Caption Script] 📂 File selected: "${videoFile.name}"`);
            }
        }
    }, true);

    // Watch DOM for popup caption input box
    const observer = new MutationObserver(() => {
        if (!lastVideoFilename) return;

        const captionInput = document.querySelector(
            '.popup-input-container .input-message-input[contenteditable="true"]'
        );

        if (captionInput) {
            console.log('[TG Caption Script] 🟩 Popup caption input found.');

            if (captionInput.innerText.trim() === '') {
                console.log(`[TG Caption Script] 📝 Inserting caption: "${lastVideoFilename}"`);

                captionInput.focus();
                document.execCommand('insertText', false, lastVideoFilename);
                captionInput.dispatchEvent(new InputEvent('input', { bubbles: true }));

                lastVideoFilename = null; // reset
            } else {
                console.log('[TG Caption Script] 🟡 Caption box not empty, skipping.');
            }
        } else {
            console.log('[TG Caption Script] 🔍 Waiting for popup caption input...');
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });

    console.log('[TG Caption Script] 👀 Observer is watching for caption input.');
})();
