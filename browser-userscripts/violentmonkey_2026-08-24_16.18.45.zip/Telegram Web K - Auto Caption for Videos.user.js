// ==UserScript==
// @name         Telegram Web K - Auto Caption for Videos
// @namespace    http://tampermonkey.net/
// @version      1.2
// @description  Automatically adds filename as caption when uploading videos on Telegram Web K version via drag & drop or file picker.
// @author       GPT
// @match        https://web.telegram.org/k/*
// @grant        none
// ==/UserScript==

(function () {
    'use strict';

    let lastVideoFilename = null;

    // Monitor drag-and-drop or file selection
    document.addEventListener('drop', (e) => {
        const file = [...e.dataTransfer.files].find(f => f.type.startsWith('video/'));
        if (file) {
            lastVideoFilename = file.name.replace(/\.[^/.]+$/, "");
        }
    }, true);

    // Also catch manual file selection
    document.addEventListener('change', (e) => {
        const input = e.target;
        if (input.type === 'file') {
            const file = [...input.files].find(f => f.type.startsWith('video/'));
            if (file) {
                lastVideoFilename = file.name.replace(/\.[^/.]+$/, "");
            }
        }
    }, true);

    // Observe the DOM for the caption input area
    const observer = new MutationObserver(() => {
        if (!lastVideoFilename) return;

        const captionBox = document.querySelector('div[contenteditable="true"][data-placeholder="Add a caption"]');
        if (captionBox && captionBox.innerText.trim() === '') {
            captionBox.focus();

            // Simulate input
            document.execCommand('insertText', false, lastVideoFilename);
            captionBox.dispatchEvent(new InputEvent('input', { bubbles: true }));

            lastVideoFilename = null; // reset after use
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
})();
